-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 13, 2020 at 09:25 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ddpro`
--
CREATE DATABASE IF NOT EXISTS `ddpro` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ddpro`;

-- --------------------------------------------------------

--
-- Table structure for table `login_info`
--

CREATE TABLE `login_info` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(80) DEFAULT NULL,
  `password` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login_info`
--

INSERT INTO `login_info` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin1029'),
(3, 'trial2', 'trytry'),
(4, 'ks', 'keykey');

-- --------------------------------------------------------

--
-- Table structure for table `movies_info`
--

CREATE TABLE `movies_info` (
  `id` int(2) NOT NULL,
  `movie_name` varchar(255) NOT NULL,
  `trailer_address` varchar(222) NOT NULL,
  `vid_poster` varchar(255) NOT NULL,
  `poster` varchar(255) NOT NULL,
  `genres` varchar(255) NOT NULL,
  `cast` varchar(255) NOT NULL,
  `director` varchar(255) NOT NULL,
  `rating` float NOT NULL,
  `release_date` date NOT NULL,
  `duration` int(4) NOT NULL,
  `age_rating` varchar(10) NOT NULL,
  `streaming` varchar(255) DEFAULT NULL,
  `plot` varchar(600) NOT NULL,
  `added_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `movies_info`
--

INSERT INTO `movies_info` (`id`, `movie_name`, `trailer_address`, `vid_poster`, `poster`, `genres`, `cast`, `director`, `rating`, `release_date`, `duration`, `age_rating`, `streaming`, `plot`, `added_date`) VALUES
(1, 'John Wick: Chapter 3 - Parabellum', 'Movies/id=1/trailer.mov', 'Movies/id=1/wide poster.png', 'Movies/id=1/tall poster.jpg', 'Action, Crime, Thriller', 'Anjelica Huston, Halle Berry, Ian McShane, Jerome Flynn, Keanu Reeves, Lance Reddick, Laurence Fishburne, Mark Dacascos, Saïd Taghmaoui', 'Chad Stahelski', 7.5, '2019-05-09', 131, 'R', 'N/A', 'In this third installment of the adrenaline-fueled action franchise, skilled assassin John Wick (Keanu Reeves) returns with a $14 million price tag on his head and an army of bounty-hunting killers on his trail. After killing a member of the shadowy international assassin\'s guild, the High Table, John Wick is excommunicado, but the world\'s most ruthless hit men and women await his every turn.', '2020-07-03 10:23:27'),
(2, 'Avengers: Endgame', './Movies/id=2/trailer.mov', './Movies/id=2/wide poster.jpg', './Movies/id=2/tall poster.jpg', 'Action, Adventure, Science Fiction', 'Brie Larson, Chris Evans, Chris Hemsworth, Don Cheadle, Jeremy Renner, Mark Ruffalo, Paul Rudd, Robert Downey Jr., Scarlett Johansson', 'Anthony Russo, Joe Russo', 8.4, '2019-04-26', 181, 'PG-13', 'N/A', 'After the devastating events of Avengers: Infinity War, the universe is in ruins due to the efforts of the Mad Titan, Thanos. With the help of remaining allies, the Avengers must assemble once more in order to undo Thanos\' actions and restore order to the universe once and for all, no matter what consequences may be in store.', '2020-07-05 00:46:07'),
(3, 'Toy Story 4', './Movies/id=3/trailer.mov', './Movies/id=3/wide poster.jpeg', './Movies/id=3/tall poster.jpg', 'Adventure, Animation, Comedy, Family', 'Annie Potts, Blake Clark, Joan Cusack, Jodi Benson, John Ratzenberger, Keanu Reeves, Tim Allen, Tom Hanks, Wallace Shawn', 'Josh Cooley', 7.8, '2019-06-21', 100, 'G', 'N/A', 'Woody has always been confident about his place in the world and that his priority is taking care of his kid, whether that\'s Andy or Bonnie. But when Bonnie adds a reluctant new toy called \"Forky\" to her room, a road trip adventure alongside old and new friends will show Woody how big the world can be for a toy.', '2020-07-10 17:43:56'),
(4, 'A Silent Voice', './Movies/id=4/trailer.mp4', './Movies/id=4/wide poster.jpg', './Movies/id=4/tall poster.jpg', 'Animation, Drama, Family, Romance', 'Aoi Yuki, Miyu Irino,Saori Hayami', 'Aoi Yuki, Koichi Yamadera, Megumi Han, Miyu Irino, Saori Hayami', 8.2, '2019-06-05', 130, 'Not Rated', 'N/A', 'When the deaf Shouko Nishimiya transfers into his class, Shouya and the rest of his class thoughtlessly bully her for fun. However, when her mother notifies the school, he is singled out and blamed for everything done to her. Now in his third year of high school, Shouya is still plagued by his wrongdoings as a young boy. Sincerely regretting his past actions, he sets out on a journey of redemption: to meet Shouko once more and make amends.', '2020-07-10 18:01:10'),
(5, 'Captain Marvel', './Movies/id=5/trailer.mov', './Movies/id=5/wide poster.jpg', './Movies/id=5/tall poster.jpg', 'Action, Adventure, Science Fiction, Superhero', 'Annette Bening, Ben Mendelsohn, Brie Larson, Clark Gregg, Gemma Chan, Jude Law, Lashana Lynch, Lee Pace, Samuel L. Jackson', 'Ryan Fleck', 6.9, '2019-03-08', 124, 'PG-13', 'N/A', 'The story follows Carol Danvers as she becomes one of the universe’s most powerful heroes when Earth is caught in the middle of a galactic war between two alien races. Set in the 1990s, Captain Marvel is an all-new adventure from a previously unseen period in the history of the Marvel Cinematic Universe.', '2020-07-10 18:29:49'),
(6, 'The Jungle Book', './Movies/id=6/trailer.mp4', './Movies/id=6/wide poster.jpg', './Movies/id=6/tall poster.jpg', 'dventure, Drama, Fantasy', 'Ben Kingsley, Bill Murray, Christopher Walken, Garry Shandling, Giancarlo Esposito, Idris Elba, Lupita Nyong\'o, Neel Sethi, Scarlett Johansson', 'Jon Favreau', 7.4, '2016-04-15', 106, 'PG', 'n/a', 'After a threat from the tiger Shere Khan forces him to flee the jungle, a man-cub named Mowgli embarks on a journey of self discovery with the help of panther Bagheera and free-spirited bear Baloo.', '2020-07-10 18:35:21'),
(7, 'The Social Network', './Movies/id=7/trailer.mp4', './Movies/id=7/wide poster.png', './Movies/id=7/tall poster.jpg', 'Biography, Drama', 'Andrew Garfield, Armie Hammer, Brenda Song, Jesse Eisenberg, John Getz, Justin Timberlake, Max Minghella, Rashida Jones, Rooney Mara', 'David Fincher', 7.7, '2010-10-01', 120, 'PG-13', '', 'On a fall night in 2003, Harvard undergrad and computer programming genius Mark Zuckerberg sits down at his computer and heatedly begins working on a new idea. In a fury of blogging and programming, what begins in his dorm room as a small site among friends soon becomes a global social network and a revolution in communication. A mere six years and 500 million friends later, Mark Zuckerberg is the youngest billionaire in history... but for this entrepreneur, success leads to both personal and legal complications.', '2020-07-10 18:45:58'),
(8, 'Chhapaak', './Movies/id=8/trailer.mp4', './Movies/id=8/wide poster.jpeg', './Movies/id=8/tall poster.jpg', 'Biography, Drama ', 'Deepika Padukone, Vikrant Massey, Madhurjeet Sarghi ', 'Meghna Gulzar', 5.1, '2020-01-10', 120, 'Unrated', 'n/a', 'The trials and triumphs of Malti, an acid attack survivor. From the investigation of the attack to the court proceedings, the medical treatment to the emotional healing. Chhapaak is the story of the unquashable human spirit.', '2020-07-10 18:51:00'),
(9, 'Men in Black: International', './Movies/id=9/trailer.mp4', './Movies/id=9/wide poster.jpg', './Movies/id=9/tall poster.jpg', ' Action, Adventure, Comedy, Science Fiction', 'Chris Hemsworth, Emma Thompson, Jess Radomska, Kumail Nanjiani, Liam Neeson, Rafe Spall, Rebecca Ferguson, Tessa Thompson, Viktorija Faith', 'F. Gary Gray', 5.6, '2019-06-14', 115, 'PG-13', 'N/A', 'The Men in Black have always protected the Earth from the scum of the universe. In this new adventure, they tackle their biggest, most global threat to date: a mole in the Men in Black organization.', '2020-07-10 19:19:50'),
(10, 'Baby Driver', './Movies/id=10/trailer.mp4', './Movies/id=10/wide poster.jpg', './Movies/id=10/tall poster.jpg', 'Action, Crime, Thriller', 'Ansel Elgort, Eiza González, Flea, Hudson Meek, Jamie Foxx, Jon Bernthal, Jon Hamm, Kevin Spacey, Lily James, Sky Ferreira', 'Edgar Wright', 7.6, '2017-06-28', 113, 'R', 'MX Player', 'After being coerced into working for a crime boss, a young getaway driver finds himself taking part in a heist doomed to fail.', '2020-07-10 19:27:02'),
(11, 'Joker', './Movies/id=11/trailer.mp4', './Movies/id=11/wide poster.jpg', './Movies/id=11/tall poster.jpeg', 'Crime, Drama, Thriller', 'Brett Cullen, Bryan Callen, Douglas Hodge, Frances Conroy, Joaquin Phoenix, Marc Maron, Robert De Niro, Shea Whigham, Zazie Beetz', 'Todd Phillips', 8.5, '2019-10-04', 121, 'R', 'Amazon Prime', 'In Gotham City, mentally troubled comedian Arthur Fleck is disregarded and mistreated by society. He then embarks on a downward spiral of revolution and bloody crime. This path brings him face-to-face with his alter-ego: the Joker.', '2020-07-10 19:30:09'),
(12, 'Deadpool 2', './Movies/id=12/trailer.mp4', './Movies/id=12/wide poster.jpg', './Movies/id=12/tall poster.jpg', 'Action, Comedy, Science Fiction', 'Brianna Hildebrand, Jack Kesy, Josh Brolin, Julian Dennison, Morena Baccarin, Ryan Reynolds, Stefan Kapičić, T.J. Miller, Zazie Beetz', 'David Leitch', 7.7, '2018-05-18', 119, 'R', '', 'Foul-mouthed mutant mercenary Wade Wilson (a.k.a. Deadpool), brings together a team of fellow mutant rogues to protect a young boy with supernatural abilities from the brutal, time-traveling cyborg Cable.', '2020-07-11 07:34:04'),
(13, 'The Irishman', './Movies/id=13/trailer.mp4', './Movies/id=13/wide poster.png', './Movies/id=13/tall poster.jpg', 'Crime, Drama, History', 'Al Pacino, Anna Paquin, Bobby Cannavale, Harvey Keitel, Joe Pesci, Ray Romano, Robert De Niro, Stephanie Kurtzuba, Stephen Graham', 'Martin Scorsese', 7.9, '2019-11-27', 209, 'R', '', 'Pennsylvania, 1956. Frank Sheeran, a war veteran of Irish origin who works as a truck driver, accidentally meets mobster Russell Bufalino. Once Frank becomes his trusted man, Bufalino sends him to Chicago with the task of helping Jimmy Hoffa, a powerful union leader related to organized crime, with whom Frank will maintain a close friendship for nearly twenty years.', '2020-07-11 07:34:04'),
(14, 'Harry Potter and the Goblet of Fire', './Movies/id=14/trailer.mp4', './Movies/id=14/wide poster.jpg', './Movies/id=14/tall poster.jpg', 'Adventure, Family, Fantasy', 'Alan Rickman, Brendan Gleeson, Daniel Radcliffe, Emma Watson, Michael Gambon, Miranda Richardson, Ralph Fiennes, Robbie Coltrane, Rupert Grint', ' Mike Newell', 7.7, '2005-11-18', 157, 'PG-13', '', 'Harry starts his fourth year at Hogwarts, competes in the treacherous Triwizard Tournament and faces the evil Lord Voldemort. Ron and Hermione help Harry manage the pressure – but Voldemort lurks, awaiting his chance to destroy Harry and all that he stands for.', '2020-07-11 07:34:04'),
(15, 'Brightburn', './Movies/id=15/trailer.mp4', './Movies/id=15/wide poster.jpg', './Movies/id=15/tall poster.jpg', 'Drama, Horror, Science Fiction, Thriller', 'Becky Wahlstrom, David Denman, Elizabeth Banks, Jennifer Holland, Matt Jones, Meredith Hagner, Stephen Blackehart, Steve Agee, Terence Rosemore', 'David Yarovesky', 6.1, '2019-05-24', 90, 'R', '', 'What if a child from another world crash-landed on Earth, but instead of becoming a hero to mankind, he proved to be something far more sinister?', '2020-07-11 07:34:04'),
(16, 'A Quiet Place', './Movies/id=16/trailer.mp4', './Movies/id=16/wide poster.jpg', './Movies/id=16/tall poster.jpg', 'Drama, Horror, Thriller', 'Cade Woodward, Doris McCarthy, Emily Blunt, John Krasinski, Leon Russom, Millicent Simmonds, Noah Jupe', 'John Krasinski', 7.5, '2018-04-06', 95, 'PG-13', '', 'In a post-apocalyptic world, a family is forced to live in silence while hiding from monsters with ultra-sensitive hearing.', '2020-07-11 07:34:04'),
(17, 'Detective Pikachu', './Movies/id=17/trailer.mp4', './Movies/id=17/wide poster.jpg', './Movies/id=17/tall poster.png', 'Comedy, Crime, Family, Fantasy, Mystery, Science Fiction', 'Alejandro De Mesa, Bill Nighy, Chris Geere, Josette Simon, Justice Smith, Kathryn Newton, Ken Watanabe, Ryan Reynolds, Suki Waterhouse', 'Rob Letterman', 6.6, '2019-05-10', 105, 'PG', '', 'In a world where people collect Pokémon to do battle, a boy comes across an intelligent talking Pikachu who seeks to be a detective.', '2020-07-11 07:34:04'),
(18, 'The Adventures of Tintin', './Movies/id=18/trailer.mp4', './Movies/id=18/wide poster.jpg', './Movies/id=18/tall poster.jpg', 'Adventure, Animation, Mystery', 'Andy Serkis, Cary Elwes, Daniel Craig, Jamie Bell, Mackenzie Crook, Nick Frost, Simon Pegg, Toby Jones, Tony Curran', 'Steven Spielberg', 7.3, '2011-12-21', 107, 'PG', '', 'Intrepid young reporter, Tintin and his loyal dog, Snowy are thrust into a world of high adventure when they discover a ship carrying an explosive secret. Tintin endeavors to find The Unicorn, a sunken ship that may hold a vast fortune, but also an ancient curse.', '2020-07-11 07:34:04'),
(19, 'Interstellar', './Movies/id=19/trailer.mp4', './Movies/id=19/wide poster.jpg', './Movies/id=19/tall poster.jpg', 'Adventure, Drama, Science Fiction', 'Anne Hathaway, Bill Irwin, Casey Affleck, Jessica Chastain, Mackenzie Foy, Matt Damon, Matthew McConaughey, Michael Caine, Timothée Chalamet', 'Christopher Nolan', 8.6, '2014-11-07', 169, 'PG-13', '', 'Interstellar chronicles the adventures of a group of explorers who make use of a newly discovered wormhole to surpass the limitations on human space travel and conquer the vast distances involved in an interstellar voyage.', '2020-07-11 07:34:04'),
(20, 'Inception', './Movies/id=20/trailer.mp4', './Movies/id=20/wide poster.jpg', './Movies/id=20/tall poster.jpg', 'Action, Adventure, Sci-Fi ', 'Cillian Murphy, Dileep Rao, Ellen Page, Joseph Gordon-Levitt, Ken Watanabe, Leonardo DiCaprio, Marion Cotillard, Michael Caine, Tom Hardy', 'Christopher Nolan', 8.8, '2010-07-16', 148, 'PG-13', '', 'Cobb, a skilled thief who commits corporate espionage by infiltrating the subconscious of his targets is offered a chance to regain his old life as payment for a task considered to be impossible: \"inception\", the implantation of another person\'s idea into a target\'s subconscious.', '2020-07-11 07:34:04'),
(21, 'Bird Box', './Movies/id=21/trailer.mp4', './Movies/id=21/wide poster.jpg', './Movies/id=21/tall poster.jpg', 'Drama, Horror, Science Fiction, Thriller', 'Danielle Macdonald, Happy Anderson, Jacki Weaver, John Malkovich, LilRel Howery, Rosa Salazar, Sandra Bullock, Sarah Paulson, Trevante Rhodes', 'Susanne Bier', 6.6, '2018-12-21', 117, 'R', '', 'Five years after an ominous unseen presence drives most of society to suicide, a mother and her two children make a desperate bid to reach safety.', '2020-07-11 07:34:04');

-- --------------------------------------------------------

--
-- Table structure for table `movie_requests`
--

CREATE TABLE `movie_requests` (
  `id` int(10) UNSIGNED NOT NULL,
  `movie_name` varchar(255) NOT NULL,
  `movie_desc` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `movie_requests`
--

INSERT INTO `movie_requests` (`id`, `movie_name`, `movie_desc`) VALUES
(1, 'Jumangi', 'A movie about game'),
(2, 'Jumangi', 'Game movie');

-- --------------------------------------------------------

--
-- Table structure for table `movie_reviews`
--

CREATE TABLE `movie_reviews` (
  `id` int(11) NOT NULL,
  `rev_username` varchar(100) DEFAULT NULL,
  `rev_user_avatar` varchar(100) DEFAULT NULL,
  `rev_review` varchar(600) DEFAULT NULL,
  `rev_movie_id` int(11) DEFAULT NULL,
  `rev_rating` decimal(3,1) DEFAULT NULL,
  `rev_review_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `movie_reviews`
--

INSERT INTO `movie_reviews` (`id`, `rev_username`, `rev_user_avatar`, `rev_review`, `rev_movie_id`, `rev_rating`, `rev_review_date`) VALUES
(1, ' ', './Avatars/blue-avatar.png', 'The best Marvel movie ever. I love it.', 2, '10.0', '2020-07-13 06:03:15'),
(3, 'trial2', './Avatars/black-avatar.png', 'Nice movie', 2, '9.5', '2020-07-13 06:04:21'),
(5, ' ', './Avatars/o-avatar.png', 'Review by @trialacc', 2, '9.5', '2020-07-13 07:09:07');

-- --------------------------------------------------------

--
-- Table structure for table `site_feedback`
--

CREATE TABLE `site_feedback` (
  `id` int(10) UNSIGNED NOT NULL,
  `feedback` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `site_feedback`
--

INSERT INTO `site_feedback` (`id`, `feedback`) VALUES
(1, 'Nice'),
(2, 'Nice');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(80) DEFAULT NULL,
  `first_name` varchar(80) DEFAULT NULL,
  `last_name` varchar(80) DEFAULT NULL,
  `email_id` varchar(80) DEFAULT NULL,
  `phone_no` char(10) DEFAULT NULL,
  `avatar_addr` varchar(255) DEFAULT NULL,
  `file_addr` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `username`, `first_name`, `last_name`, `email_id`, `phone_no`, `avatar_addr`, `file_addr`) VALUES
(1, 'admin', 'DDProject', 'admin', 'your@email.com', '', './Avatars/black-avatar.png', './Users/admin/list.txt'),
(3, 'trial2', 'trial2', 'Account', 'keyur2002solanki@gmail.com', '8686868686', './Avatars/black-avatar.png', './Users/trial2/list.txt'),
(4, 'ks', 'Keyur', 'Solanki', 'keyur2002solanki@gmail.com', '8686868686', './Avatars/yel-avatar.png', './Users/ks/list.txt');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login_info`
--
ALTER TABLE `login_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `movies_info`
--
ALTER TABLE `movies_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `movie_requests`
--
ALTER TABLE `movie_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `movie_reviews`
--
ALTER TABLE `movie_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `site_feedback`
--
ALTER TABLE `site_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login_info`
--
ALTER TABLE `login_info`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `movie_requests`
--
ALTER TABLE `movie_requests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `movie_reviews`
--
ALTER TABLE `movie_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `site_feedback`
--
ALTER TABLE `site_feedback`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
